"""Classroom bounded context."""
