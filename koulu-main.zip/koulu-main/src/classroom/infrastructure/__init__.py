"""Classroom infrastructure layer."""
