"""Classroom application layer."""
