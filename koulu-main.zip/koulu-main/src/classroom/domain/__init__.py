"""Classroom domain layer."""
